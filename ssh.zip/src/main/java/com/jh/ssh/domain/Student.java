package com.jh.ssh.domain;

public class Student {
    int id;
    String name;
    String gender;
    int number;
    int age;
    String description;
}
